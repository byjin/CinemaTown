Custom BottomNavigationView
-------------------------------

BottomNavigationView is for creating prevent icon shifting after implement example you can see your icon not shift
Inside application i will create 4 static menu and click on every menu other icon not shift or move.

If my example really helpful to you then please don't forgot to press `Star` icon.


**Important Note :**
------------------------
Please don't use example bottom navigation icon please create your own icon and use.

Screenshots
-----------

![screenshot][1]

[1]: ./art/art.gif
