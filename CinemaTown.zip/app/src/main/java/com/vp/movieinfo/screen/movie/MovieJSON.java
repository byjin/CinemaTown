package com.vp.movieinfo.screen.movie;

import android.content.Context;
import android.util.Log;

import com.vp.movieinfo.utils.SharedPrefsUtils;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class MovieJSON {

    // 일별 박스오피스 API 호출
    public static JSONArray getMovieData(Context context) throws Exception {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd");
        Calendar calendar = Calendar.getInstance();
        calendar.add(calendar.DATE, -1);

        String key = "c9f81372317a1375605232c1a7894a20";
        String targetDt = simpleDateFormat.format(calendar.getTime());

        HttpClient client = new DefaultHttpClient();
        URI uri = new URIBuilder("http://www.kobis.or.kr/kobisopenapi/webservice/rest/boxoffice/searchDailyBoxOfficeList.json")
                .addParameter("key", key)        //일별 박스오피스 API 서비스//영화진흥위원회
                .addParameter("targetDt", targetDt)
                .build();
        HttpGet httpGet = new HttpGet(uri);
        HttpResponse resp = client.execute(httpGet);
        String result = EntityUtils.toString(resp.getEntity(), "UTF-8");
//        System.out.println(result);

        JSONParser parser = new JSONParser();
        JSONObject jsonObject = (JSONObject) parser.parse(result);
        JSONObject jsonObject2 = (JSONObject) jsonObject.get("boxOfficeResult");
        JSONArray jsonArray = (JSONArray) jsonObject2.get("dailyBoxOfficeList");
        SharedPrefsUtils.setStringPreference(context, "MovieData", jsonArray.toString());

        return jsonArray;
    }
}
