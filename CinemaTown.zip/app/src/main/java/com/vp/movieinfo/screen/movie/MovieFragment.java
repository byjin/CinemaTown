package com.vp.movieinfo.screen.movie;

import android.os.AsyncTask;
import android.os.Bundle;
import android.os.NetworkOnMainThreadException;
import android.os.StrictMode;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.vp.movieinfo.R;
import com.vp.movieinfo.utils.SharedPrefsUtils;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MovieFragment extends Fragment {

    @BindView(R.id.movie_empty_textview)
    TextView movieEmptyTextview;
    @BindView(R.id.movie_list_recyclerview)
    RecyclerView movieListRecyclerview;
    @BindView(R.id.progressbar)
    ProgressBar progressbar;

    private MovieListAdapter movieListAdapter;
    private String sharedMovieListData;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_movie, container, false);
        ButterKnife.bind(this, rootView);

        initView();

        return rootView;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        sharedMovieListData = SharedPrefsUtils.getStringPreference(getContext(), "MovieData");
        if (sharedMovieListData == null || sharedMovieListData.length() <= 0){
            MyAsyncTask myAsyncTask = new MyAsyncTask();
            myAsyncTask.execute(0);

        } else {
            addMovieListData(convertStringToJsonArray());
        }
    }

    // 뷰 세팅
    private void initView() {
        movieListRecyclerview.setLayoutManager(new LinearLayoutManager(getContext()));
        movieListAdapter = new MovieListAdapter(getContext());
        movieListRecyclerview.setAdapter(movieListAdapter);
    }

    // 박스오피스 API 정보 요청
    private void requestMovieListData() {
        try {
            MovieJSON movieJSON = new MovieJSON();
            movieJSON.getMovieData(getContext());

        } catch (NetworkOnMainThreadException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // 받아온 데아타 리스트 데이타 생성
    private void addMovieListData(JSONArray jsonArray) {
        if (jsonArray.size() > 0) {
            movieListRecyclerview.setVisibility(View.VISIBLE);
            movieEmptyTextview.setVisibility(View.GONE);
            movieListAdapter.getMovieItemDataList().clear();
            movieListAdapter.getMovieItemDataList().add(new MovieItemData(getString(R.string.movie_item_no_title),
                    getString(R.string.movie_item_movie_name_title),
                    getString(R.string.movie_item_count_title),
                    "",
                    ""));
            for (int i = 0; i < jsonArray.size(); i++) {
                JSONObject jsonObject = (JSONObject) jsonArray.get(i);
                MovieItemData movieItemData = new MovieItemData(i + 1 + "",
                        jsonObject.get("movieNm").toString(),
                        jsonObject.get("audiCnt").toString(),
                        jsonObject.get("audiAcc").toString(),
                        jsonObject.get("audiInten").toString());
                movieListAdapter.getMovieItemDataList().add(movieItemData);
            }
            movieListAdapter.notifyDataSetChanged();

        } else {
            movieListRecyclerview.setVisibility(View.GONE);
            movieEmptyTextview.setVisibility(View.VISIBLE);
        }
    }

    // String 데이타 JSONArray 타입으로 컨버팅
    private JSONArray convertStringToJsonArray() {
        Object object = null;
        JSONArray jsonArray = null;
        JSONParser jsonParser = new JSONParser();
        try {
            object = jsonParser.parse(sharedMovieListData);
            jsonArray = (JSONArray) object;

        } catch (ParseException e) {
            e.printStackTrace();
        }
        return jsonArray;
    }

    // 박스오피스 API 정보 요청을 위한 비동기 처리
    public class MyAsyncTask extends AsyncTask<Integer, Integer, Integer> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressbar.setVisibility(View.VISIBLE);
        }

        @Override
        protected Integer doInBackground(Integer... integers) {
            requestMovieListData();
            return 0;
        }

        @Override
        protected void onPostExecute(Integer result) {
            super.onPostExecute(result);
            sharedMovieListData = SharedPrefsUtils.getStringPreference(getContext(), "MovieData");
            addMovieListData(convertStringToJsonArray());
            progressbar.setVisibility(View.GONE);
        }

        @Override
        protected void onCancelled() {
            super.onCancelled();
        }
    }
}
