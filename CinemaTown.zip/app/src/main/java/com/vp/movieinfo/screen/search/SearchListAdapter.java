package com.vp.movieinfo.screen.search;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.vp.movieinfo.R;
import com.vp.movieinfo.screen.movie.MovieItemData;

import java.util.ArrayList;

public class SearchListAdapter extends RecyclerView.Adapter<SearchListAdapter.ViewHolder> {

    private Context context;
    private LayoutInflater inflater;
    private ArrayList<SearchItemData> searchItemDataList = new ArrayList<>();

    public SearchListAdapter(Context context) {
        this.context = context;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public SearchListAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.search_movie_list_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(SearchListAdapter.ViewHolder holder, int position) {

        String title = searchItemDataList.get(position).getTitle().replace("<b>", "");
        String lastTitle = title.replace("</b>", "");
        holder.title.setText(lastTitle);
        holder.rating.setText(searchItemDataList.get(position).getRating());
        holder.subTitle.setText(searchItemDataList.get(position).getSubtitle());
        holder.pubDate.setText(searchItemDataList.get(position).getPubdate());
        holder.director.setText(searchItemDataList.get(position).getDirector());
        holder.actor.setText(searchItemDataList.get(position).getActor());
        holder.link.setText(searchItemDataList.get(position).getLink());
        Glide.with(context).load(searchItemDataList.get(position).getImage()).into(holder.image);
    }

    @Override
    public int getItemCount() {
        return searchItemDataList.size();
    }

    public void setSearchItemData(ArrayList<SearchItemData> searchItemDataList) {
        this.searchItemDataList = searchItemDataList;
    }

    public ArrayList<SearchItemData> getSearchItemData() {
        return searchItemDataList;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView title;
        TextView rating;
        ImageView image;
        TextView subTitle;
        TextView pubDate;
        TextView director;
        TextView actor;
        TextView link;

        public ViewHolder(View itemView) {
            super(itemView);

            title = itemView.findViewById(R.id.search_item_title_textview);
            rating = itemView.findViewById(R.id.search_item_rating_textview);
            image = itemView.findViewById(R.id.search_item_imageview);
            subTitle = itemView.findViewById(R.id.search_item_subtitle_textview);
            pubDate = itemView.findViewById(R.id.search_item_pubdate_textview);
            director = itemView.findViewById(R.id.search_item_director_textview);
            actor = itemView.findViewById(R.id.search_item_actor_textview);
            link = itemView.findViewById(R.id.search_item_link_textview);
        }
    }
}
