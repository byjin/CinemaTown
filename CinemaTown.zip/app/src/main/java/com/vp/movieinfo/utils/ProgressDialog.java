package com.vp.movieinfo.utils;

import android.content.Context;
import android.os.Build;

public class ProgressDialog {

    private static android.app.ProgressDialog progressDialog;

    public static void show(Context context) {
        if (progressDialog != null) {
            progressDialog.dismiss();
        }

        int style;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            style = android.R.style.Theme_Material_Light_Dialog;
        } else {
            //noinspection deprecation
            style = android.app.ProgressDialog.THEME_HOLO_LIGHT;
        }

        progressDialog = new android.app.ProgressDialog(context, style);
        progressDialog.setCancelable(false);
        progressDialog.show();
    }

    public static void dismiss() {
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
            progressDialog = null;
        }
    }
}
