package com.vp.movieinfo.screen.search;

public class SearchItemData {

    public String no;
    public String title;
    public String rating;
    public String image;
    public String subtitle;
    public String pubdate;
    public String director;
    public String actor;
    public String link;

    public SearchItemData(String no, String title, String rating, String image, String subtitle, String pubdate, String director, String actor, String link) {
        this.no = no;
        this.title = title;
        this.rating = rating;
        this.image = image;
        this.subtitle = subtitle;
        this.pubdate = pubdate;
        this.director = director;
        this.actor = actor;
        this.link = link;
    }

    public String getNo() {
        return no;
    }

    public String getTitle() {
        return title;
    }

    public String getRating() {
        return rating;
    }

    public String getImage() {
        return image;
    }

    public String getSubtitle() {
        return subtitle;
    }

    public String getPubdate() {
        return pubdate;
    }

    public String getDirector() {
        return director;
    }

    public String getActor() {
        return actor;
    }

    public String getLink() {
        return link;
    }
}
