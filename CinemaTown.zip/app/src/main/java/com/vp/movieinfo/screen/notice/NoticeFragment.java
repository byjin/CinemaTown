package com.vp.movieinfo.screen.notice;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.getbase.floatingactionbutton.AddFloatingActionButton;
import com.vp.movieinfo.R;
import com.vp.movieinfo.data.db.DBManager;
import com.vp.movieinfo.utils.GPSTracker;
import com.vp.movieinfo.utils.InputDialog;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class NoticeFragment extends Fragment {

    @BindView(R.id.gps_toggle)
    ToggleButton gpsToggle;
    @BindView(R.id.setting_layout)
    LinearLayout settingLayout;
    @BindView(R.id.notice_layout)
    RelativeLayout noticeLayout;
    @BindView(R.id.board_item_add_button)
    AddFloatingActionButton boardItemAddButton;
    @BindView(R.id.board_empty_textview)
    TextView boardEmptyTextview;
    @BindView(R.id.board_list_recyclerview)
    RecyclerView boardListRecyclerview;

    private DBManager dbManager;
    private NoticeListAdapter noticeListAdapter;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable final ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_notice, container, false);
        ButterKnife.bind(this, rootView);

        // 화면 포커스 리스너
        rootView.getViewTreeObserver().addOnWindowFocusChangeListener(new ViewTreeObserver.OnWindowFocusChangeListener() {
            @Override
            public void onWindowFocusChanged(final boolean hasFocus) {
                setGpsToggleOnOff(GPSTracker.isGpsService(getContext()));
            }
        });

        // 백키 세팅
        rootView.setFocusableInTouchMode(true);
        rootView.requestFocus();
        rootView.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
                    if (settingLayout.getVisibility() == View.VISIBLE) {
                        getActivity().finish();
                    } else {
                        settingLayout.setVisibility(View.VISIBLE);
                        noticeLayout.setVisibility(View.GONE);
                    }
                    return true;
                }
                return false;
            }
        });


        init();

        return rootView;
    }

    // 클릭 이벤트
    @OnClick(R.id.notice_category)
    public void noticeCategoryOnclick(View view) {
        settingLayout.setVisibility(View.GONE);
        noticeLayout.setVisibility(View.VISIBLE);
    }

    private void init() {
        setGpsToggleOnOff(GPSTracker.isGpsService(getContext()));
        gpsToggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    requestGpsSetting();
                }
            }
        });

        dbManager = new DBManager(getContext());
        dbManager.open();

        boardListRecyclerview.setLayoutManager(new LinearLayoutManager(getContext()));
        noticeListAdapter = new NoticeListAdapter(getContext());
        boardListRecyclerview.setAdapter(noticeListAdapter);

        boardItemAddButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editDialog();
            }
        });

        if (getListData().size() > 0) {
            boardListRecyclerview.setVisibility(View.VISIBLE);
            boardEmptyTextview.setVisibility(View.GONE);

        } else {
            boardListRecyclerview.setVisibility(View.GONE);
            boardEmptyTextview.setVisibility(View.VISIBLE);
        }
    }

    private void setGpsToggleOnOff(boolean hasFocus) {
        if (hasFocus) {
            gpsToggle.setChecked(true);
        } else {
            gpsToggle.setChecked(false);
        }
    }

    // GPS 설정 이동
    private void requestGpsSetting() {
        getActivity().startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
    }

    // DB에 있는 데이타 가져와서 리스트 형태로 저장
    private ArrayList<NoticeItemData> getListData() {
        ArrayList<NoticeItemData> noticeItemDataList = new ArrayList<>();
        Cursor cursor = dbManager.fetch();
        if (cursor.getCount() > 0) {
            for (int i = 0; i < cursor.getCount(); i++) {
                NoticeItemData noticeItemData = new NoticeItemData(i + 1 + "", cursor.getString(0));
                noticeItemDataList.add(noticeItemData);
                cursor.moveToNext();
            }

            noticeListAdapter.setNoticeItemDataList(noticeItemDataList);
            noticeListAdapter.notifyDataSetChanged();
        }

        return noticeItemDataList;
    }

    // 게시판 입력 위한 다이얼로그
    private void editDialog() {
        new InputDialog.Builder(getContext())
                .setTitle(getString(R.string.menu_search))
                .setInputMaxWords(300)
                .setInputHint(getString(R.string.notice_dialog_contents_hint))
                .setPositiveButton(getString(R.string.notice_dialog_yes), new InputDialog.ButtonActionListener() {
                    @Override
                    public void onClick(CharSequence inputText) {
                        // TODO
                        dbManager.insert("", inputText.toString());
                        Cursor cursor = dbManager.fetch();
                        cursor.moveToLast();
                        noticeListAdapter.getNoticeItemDataList().add(new NoticeItemData(cursor.getCount() + "", cursor.getString(0)));
                        noticeListAdapter.notifyDataSetChanged();
                        boardListRecyclerview.smoothScrollToPosition(boardListRecyclerview.getAdapter().getItemCount() - 1);
                    }
                })
                .setNegativeButton(getString(R.string.notice_dialog_no), new InputDialog.ButtonActionListener() {
                    @Override
                    public void onClick(CharSequence inputText) {
                        // TODO
                    }
                })
                .setOnCancelListener(new InputDialog.OnCancelListener() {
                    @Override
                    public void onCancel(CharSequence inputText) {
                        // TODO
                    }
                })
                .interceptButtonAction(new InputDialog.ButtonActionIntercepter() {
                    @Override
                    public boolean onInterceptButtonAction(int whichButton, CharSequence inputText) {
                        if ("/sdcard/my".equals(inputText) && whichButton == DialogInterface.BUTTON_POSITIVE) {
                            return true;
                        }
                        return false;
                    }
                })
                .show();
    }
}
