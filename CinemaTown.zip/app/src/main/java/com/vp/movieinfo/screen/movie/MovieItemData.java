package com.vp.movieinfo.screen.movie;

public class MovieItemData {

    public String no;
    public String movieNm;
    public String audiCnt;
    public String audiAcc;
    public String audiInten;

    public MovieItemData(String no, String movieNm, String audiCnt, String audiAcc, String audiInten) {
        this.no = no;
        this.movieNm = movieNm;
        this.audiCnt = audiCnt;
        this.audiAcc = audiAcc;
        this.audiInten = audiInten;
    }

    public String getNo() {
        return no;
    }

    public String getMovieNm() {
        return movieNm;
    }

    public String getAudiCnt() {
        return audiCnt;
    }

    public String getAudiAcc() {
        return audiAcc;
    }

    public String getAudiInten() {
        return audiInten;
    }
}
