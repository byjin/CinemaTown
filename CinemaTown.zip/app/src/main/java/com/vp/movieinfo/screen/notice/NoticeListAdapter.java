package com.vp.movieinfo.screen.notice;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.vp.movieinfo.R;

import java.util.ArrayList;

public class NoticeListAdapter extends RecyclerView.Adapter<NoticeListAdapter.ViewHolder> {

    private LayoutInflater inflater;
    private ArrayList<NoticeItemData> noticeItemDataList = new ArrayList<>();

    public NoticeListAdapter(Context context) {
        inflater = LayoutInflater.from(context);
    }

    @Override
    public NoticeListAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.notice_list_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(NoticeListAdapter.ViewHolder holder, int position) {

        holder.boardItemNoTextview.setText(noticeItemDataList.get(position).getNo());
        holder.boardItemContentsTextview.setText(noticeItemDataList.get(position).getContents());

    }

    @Override
    public int getItemCount() {
        return noticeItemDataList.size();
    }

    public void setNoticeItemDataList(ArrayList<NoticeItemData> noticeItemDataList) {
        this.noticeItemDataList = noticeItemDataList;
    }

    public ArrayList<NoticeItemData> getNoticeItemDataList() {
        return noticeItemDataList;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView boardItemNoTextview;
        TextView boardItemContentsTextview;

        public ViewHolder(View itemView) {
            super(itemView);

            boardItemNoTextview = itemView.findViewById(R.id.board_item_no_textview);
            boardItemContentsTextview = itemView.findViewById(R.id.board_item_contents_textview);
        }
    }
}
