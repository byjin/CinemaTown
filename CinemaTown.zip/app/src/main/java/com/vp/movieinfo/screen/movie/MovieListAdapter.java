package com.vp.movieinfo.screen.movie;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.vp.movieinfo.R;

import java.util.ArrayList;

public class MovieListAdapter extends RecyclerView.Adapter<MovieListAdapter.ViewHolder> {

    private Context context;
    private LayoutInflater inflater;
    private ArrayList<MovieItemData> movieItemDataList = new ArrayList<>();

    public MovieListAdapter(Context context) {
        this.context = context;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public MovieListAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.movie_list_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MovieListAdapter.ViewHolder holder, int position) {

        holder.no.setText(movieItemDataList.get(position).getNo());
        holder.name.setText(movieItemDataList.get(position).getMovieNm());

        if ( position == 0 ) {
            holder.accumulate.setVisibility(View.GONE);
            holder.before.setVisibility(View.GONE);
            holder.daily.setText(movieItemDataList.get(position).getAudiCnt());

        } else {
            holder.accumulate.setVisibility(View.VISIBLE);
            holder.before.setVisibility(View.VISIBLE);
            holder.daily.setText(context.getString(R.string.movie_daily) + movieItemDataList.get(position).getAudiCnt() + context.getString(R.string.movie_persons));
            holder.accumulate.setText(context.getString(R.string.movie_accumulate) + movieItemDataList.get(position).getAudiAcc() + context.getString(R.string.movie_persons));
            holder.before.setText(context.getString(R.string.movie_before) + movieItemDataList.get(position).getAudiInten() + context.getString(R.string.movie_persons));
        }
    }

    @Override
    public int getItemCount() {
        return movieItemDataList.size();
    }

    public void setMovieItemDataList(ArrayList<MovieItemData> movieItemDataList) {
        this.movieItemDataList = movieItemDataList;
    }

    public ArrayList<MovieItemData> getMovieItemDataList() {
        return movieItemDataList;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView no;
        TextView name;
        TextView daily;
        TextView accumulate;
        TextView before;

        public ViewHolder(View itemView) {
            super(itemView);

            no = itemView.findViewById(R.id.movie_item_no_textview);
            name = itemView.findViewById(R.id.movie_item_name_textview);
            daily = itemView.findViewById(R.id.movie_item_daily_textview);
            accumulate = itemView.findViewById(R.id.movie_item_accumulate_textview);
            before = itemView.findViewById(R.id.movie_item_before_textview);
        }
    }
}
