package com.vp.movieinfo.screen.notice;

public class NoticeItemData {

    public String no;
    public String contents;

    public NoticeItemData(String no, String contents) {
        this.no = no;
        this.contents = contents;
    }

    public String getNo() {
        return no;
    }

    public String getContents() {
        return contents;
    }
}
