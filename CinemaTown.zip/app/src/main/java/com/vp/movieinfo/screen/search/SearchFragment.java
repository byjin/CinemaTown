package com.vp.movieinfo.screen.search;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.NetworkOnMainThreadException;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.mancj.materialsearchbar.MaterialSearchBar;
import com.vp.movieinfo.R;
import com.vp.movieinfo.screen.movie.MovieFragment;
import com.vp.movieinfo.screen.movie.MovieItemData;
import com.vp.movieinfo.screen.movie.MovieListAdapter;
import com.vp.movieinfo.utils.SharedPrefsUtils;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class SearchFragment extends Fragment {

    @BindView(R.id.searchBar)
    MaterialSearchBar searchBar;
    @BindView(R.id.search_recyclerview)
    RecyclerView searchRecyclerView;
    @BindView(R.id.search_empty_textview)
    TextView searchEmptyTextview;
    @BindView(R.id.search_progressbar)
    ProgressBar progressbar;

    private SearchListAdapter searchListAdapter;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_search, container, false);
        ButterKnife.bind(this, rootView);

        initView();

        return rootView;
    }

    private void initView() {
        searchBar.setHint(getResources().getString(R.string.search_bar_hint));
        searchBar.setSpeechMode(false);
        searchBar.setOnSearchActionListener(new MaterialSearchBar.OnSearchActionListener() {
            @Override
            public void onSearchStateChanged(boolean enabled) {
            }

            @Override
            public void onSearchConfirmed(CharSequence text) {
                MyAsyncTask myAsyncTask = new MyAsyncTask(text.toString());
                myAsyncTask.execute();
            }

            @Override
            public void onButtonClicked(int buttonCode) {
            }
        });

        searchRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        searchListAdapter = new SearchListAdapter(getContext());
        searchRecyclerView.setAdapter(searchListAdapter);
    }

    // 검색 완료 된 데이타 리스트 데이타로 저장
    private void addSearchListdata(JSONArray jsonArray) {
        if (jsonArray.size() > 0) {
            searchListAdapter.getSearchItemData().clear();
            for (int i = 0; i < jsonArray.size(); i++) {
                JSONObject jsonObject = (JSONObject) jsonArray.get(i);
                SearchItemData searchItemData = new SearchItemData(i + 1 + "",
                        jsonObject.get("title").toString(),
                        jsonObject.get("userRating").toString(),
                        jsonObject.get("image").toString(),
                        jsonObject.get("subtitle").toString(),
                        jsonObject.get("pubDate").toString(),
                        jsonObject.get("director").toString(),
                        jsonObject.get("actor").toString(),
                        jsonObject.get("link").toString());
                searchListAdapter.getSearchItemData().add(searchItemData);
            }
            searchListAdapter.notifyDataSetChanged();

        } else {
        }
    }

    // 네이버 영로 검색 API 호출을 위한 비동기 처리
    public class MyAsyncTask extends AsyncTask<Void, Void, Integer> {

        private String search;
        private JSONArray jsonArray;

        public MyAsyncTask(String search) {
            this.search = search;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressbar.setVisibility(View.VISIBLE);
        }

        @Override
        protected Integer doInBackground(Void... params) {
            try {
                SearchJSON searchJSON = new SearchJSON();
                jsonArray = searchJSON.main(getContext(), search);

            } catch (NetworkOnMainThreadException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return 0;
        }

        @Override
        protected void onPostExecute(Integer result) {
            super.onPostExecute(result);
            progressbar.setVisibility(View.GONE);
            addSearchListdata(jsonArray);
            hideKeyboard();
        }

        @Override
        protected void onCancelled() {
            super.onCancelled();
        }
    }

    // 키보드 숨김 처리
    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Activity.INPUT_METHOD_SERVICE);
        View view = getActivity().getCurrentFocus();
        if (view == null) {
            view = new View(getActivity());
        }
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }
}
