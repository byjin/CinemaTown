package com.vp.movieinfo.screen.screen;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;

import com.vp.movieinfo.R;

import butterknife.BindView;
import butterknife.ButterKnife;

public class ScreenFragment extends Fragment {

    @BindView(R.id.screen_search_webview)
    WebView screenSearchWebview;
    @BindView(R.id.ticketing_webview)
    WebView ticketingWebview;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_cinema, container, false);
        ButterKnife.bind(this, rootView);

        initView();

        return rootView;
    }

    // 웹뷰 세팅
    private void initView() {
        screenSearchWebview.loadUrl("https://m.search.naver.com/search.naver?query=%EC%98%81%ED%99%94%EA%B4%80&sm=mtb_hty.top&where=m&oquery=dudghkrhks&tqi=THUzrlpVuowsss5ftl8sssssshC-214628");
        ticketingWebview.loadUrl("http://m.movie.yes24.com/Ticket/Region.aspx");
    }
}
