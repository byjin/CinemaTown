package com.vp.movieinfo.screen.setting;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.CompoundButton;
import android.widget.ToggleButton;

import com.vp.movieinfo.R;
import com.vp.movieinfo.utils.GPSTracker;

import butterknife.BindView;
import butterknife.ButterKnife;

public class SettingFragment extends Fragment {

    @BindView(R.id.gps_togglebutton)
    ToggleButton gpsTogglebutton;

    private GPSTracker gpsTracker;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_setting, container, false);
        ButterKnife.bind(this, rootView);

        rootView.getViewTreeObserver().addOnWindowFocusChangeListener(new ViewTreeObserver.OnWindowFocusChangeListener() {
            @Override
            public void onWindowFocusChanged(final boolean hasFocus) {
                setGpsTogglebuttonOnOff(GPSTracker.isGpsService(getContext()));
            }
        });

        initView();

        return rootView;
    }

    private void initView() {
        setGpsTogglebuttonOnOff(GPSTracker.isGpsService(getContext()));
        gpsTogglebutton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    requestGpsSetting();
                }
            }
        });
    }

    private void setGpsTogglebuttonOnOff(boolean hasFocus) {
        if (hasFocus) {
            gpsTogglebutton.setChecked(true);
        } else {
            gpsTogglebutton.setChecked(false);
        }
    }

    private void requestGpsSetting() {
        getActivity().startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
    }
}
