package com.vp.movieinfo.screen.search;

import android.content.Context;
import android.util.Log;

import com.vp.movieinfo.utils.SharedPrefsUtils;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class SearchJSON {

    // 네이버 영화 검색 API 호출
    public static JSONArray main(Context context, String search) throws Exception {

        String clientId = "UtA5TQ8iykNU5CfYuBFU";
        String clientSecret = "pKC5hRwRI2";
        String text = URLEncoder.encode(search, "UTF-8");
        String openApiUrl = "https://openapi.naver.com/v1/search/movie.json?query=" + text;

        URL url = new URL(openApiUrl);
        HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
        httpURLConnection.setRequestMethod("GET");
        httpURLConnection.setRequestProperty("X-Naver-Client-id", clientId);
        httpURLConnection.setRequestProperty("X-Naver-Client-Secret", clientSecret);

        int responseCode = httpURLConnection.getResponseCode();
        BufferedReader reader;
        if (responseCode == 200) { // 정상 호출
            reader = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()));
        } else {  // 에러 발생
            reader = new BufferedReader(new InputStreamReader(httpURLConnection.getErrorStream()));
        }
        String inputLine = "";
        StringBuilder builder = new StringBuilder();
        while ((inputLine = reader.readLine()) != null) {
            //builder.append(inputLine).append("\n");
            builder.append(inputLine);
        }
        reader.close();

        JSONParser parser = new JSONParser();
        JSONObject jsonObject = (JSONObject) parser.parse(builder.toString());
        JSONArray jsonArray = (JSONArray) jsonObject.get("items");
        //JSONObject jsonArray = (JSONObject) jsonObject;

        return jsonArray;
    }
}
