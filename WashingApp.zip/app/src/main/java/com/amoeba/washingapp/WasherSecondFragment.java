package com.amoeba.washingapp;

import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.amoeba.washingapp.widget.DonutProgress;

import java.io.IOException;

public class WasherSecondFragment extends Fragment {

    private DonutProgress countDownProgress;
    private EditText editSeconds;
    private Button timerButton;
    private Button resetButton;

    private CountDownTimer countDownTimer;
    private MediaPlayer mediaPlayer;

    private int status = 0;   // 0 : stop 1 : start
    private int currentProgress;
    private final long startTime = 10 * 1000;
    private final long interval = 1 * 1000;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_washer_second, container, false);

        initView(rootView);

        return rootView;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public void onResume(){
        super.onResume();
    }

    @Override
    public void onPause(){
        super.onPause();
        stopCountDown();
    }

    private void initView(View view) {
        editSeconds = (EditText) view.findViewById(R.id.seconds);
        timerButton = (Button) view.findViewById(R.id.timer_button);
        resetButton = (Button) view.findViewById(R.id.reset_button);
        countDownProgress = (DonutProgress) view.findViewById(R.id.countdown_progress);

        editSeconds.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence.length() > 0) {
                    currentProgress = Integer.parseInt(editSeconds.getText().toString());
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });

        timerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (status == 0) {
                    status = 1;
                    timerButton.setText("Stop Alarm");
                    countDownProgress.setMax(Integer.parseInt(editSeconds.getText().toString()));
                    countDownProgress.setProgress(currentProgress);
                    startCountDown();

                } else if (status == 1) {
                    status = 0;
                    timerButton.setText("Start Alarm");
                    countDownProgress.setProgress(currentProgress);
                    stopCountDown();
                }
            }
        });
        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                currentProgress = Integer.parseInt(editSeconds.getText().toString());
                timerButton.setText("Start Alarm");
                if (status == 0) {
                    countDownProgress.setProgress(currentProgress);

                } else if (status == 1) {
                    status = 0;
                    countDownProgress.setProgress(currentProgress);
                    stopCountDown();
                }
            }
        });
    }

    public void startCountDown() {
        countDownTimer = new CountDownTimer(currentProgress * 1000, interval) {
            @Override
            public void onTick(long millisUntilFinished) {
                currentProgress = (int) millisUntilFinished / 1000;
                countDownProgress.setProgress(currentProgress);
            }

            @Override
            public void onFinish() {
                countDownProgress.setProgress(0);
                currentProgress = Integer.parseInt(editSeconds.getText().toString());
                playSound(getContext(), getAlarmUri());
            }
        };
        countDownTimer.start();
    }

    public void stopCountDown() {
        if (countDownTimer != null) {
            countDownTimer.cancel();
            countDownTimer = null;
        }

        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }

    private void playSound(Context context, Uri alert) {
        mediaPlayer = new MediaPlayer();
        try {
            mediaPlayer.setDataSource(context, alert);
            final AudioManager audioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
            if (audioManager.getStreamVolume(AudioManager.STREAM_ALARM) != 0) {
                mediaPlayer.setAudioStreamType(AudioManager.STREAM_ALARM);
                mediaPlayer.prepare();
                mediaPlayer.start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private Uri getAlarmUri() {
        Uri alert = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        if (alert == null) {
            alert = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            if (alert == null) {
                alert = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
            }
        }
        return alert;
    }
}
