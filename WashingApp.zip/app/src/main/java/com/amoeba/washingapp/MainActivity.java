package com.amoeba.washingapp;

import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Fragment fragCategory;

    private boolean isBackToExitPressedOnce = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar().hide();

        init();
    }

    @Override
    public void onBackPressed() {
        if (fragCategory != null) {
            getSupportFragmentManager().beginTransaction().remove(fragCategory).commit();
            fragCategory = null;

        } else {
            if (isBackToExitPressedOnce) {
                super.onBackPressed();
                return;
            }

            this.isBackToExitPressedOnce = true;
            Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();

            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    isBackToExitPressedOnce = false;
                }
            }, 2000);
        }
    }

    private void init() {
        ((RelativeLayout) findViewById(R.id.room_button)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fragCategory = new RoomFragment();
                changFragmentpage();
            }
        });
        ((RelativeLayout) findViewById(R.id.washer_button)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fragCategory = new WasherSecondFragment();
                changFragmentpage();
            }
        });
        ((RelativeLayout) findViewById(R.id.alarm_button)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        ((RelativeLayout) findViewById(R.id.setting_button)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //fragCategory = new SettingFragment();
                //changFragmentpage();
            }
        });
    }

    private void changFragmentpage() {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.container, fragCategory);
        transaction.commit();
    }
}
