package com.amoeba.washingapp;

import android.content.Context;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.amoeba.washingapp.util.AnimationUtil;
import com.amoeba.washingapp.widget.CircleCountDownView;

public class WasherFragment extends Fragment {

    private CircleCountDownView mProgressHour;
    private CircleCountDownView mProgressMinute;
    private CircleCountDownView mProgressSecond;
    private EditText editHours;
    private EditText editMinutes;
    private EditText editSeconds;
    private LinearLayout upcomingTimerBox;
    private Button startTimerBt;
    private Button cancelTimerBt;

    private CountDownTimer countDownTimerSec, countDownTimerMin, countDownTimerHour;
    private int formDays = (1000 * 60 * 60 * 24);

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_washer, container, false);

        initView(rootView);

        return rootView;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public void onPause() {
        super.onPause();
        stopCountDown();
    }

    private void initView(View view) {
        mProgressHour = (CircleCountDownView) view.findViewById(R.id.item_upcoming_hour_progress);
        mProgressMinute = (CircleCountDownView) view.findViewById(R.id.item_upcoming_minute_progress);
        mProgressSecond = (CircleCountDownView) view.findViewById(R.id.item_upcoming_seconds_progress);
        editHours = (EditText) view.findViewById(R.id.hours);
        editMinutes = (EditText) view.findViewById(R.id.minutes);
        editSeconds = (EditText) view.findViewById(R.id.seconds);
        upcomingTimerBox = (LinearLayout) view.findViewById(R.id.item_upcoming_time_box);
        startTimerBt = (Button) view.findViewById(R.id.timer_button);
        cancelTimerBt = (Button) view.findViewById(R.id.reset_button);

        startTimerBt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startCountDown();
            }
        });
        cancelTimerBt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                stopCountDown();
            }
        });

        firstStartCountDown();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                stopCountDown();
            }
        }, 1000);
    }

    private void firstStartCountDown() {
        showProgressBars();

        long hoursInitTime = Long.valueOf("1");
        long minutesInitTime = Long.valueOf("1");
        long secondsInitTime = Long.valueOf("1");

        mProgressHour.setEndTime(24);
        mProgressHour.setInitTime(hoursInitTime);
        mProgressHour.setListener(new CircleCountDownView.OnFinishCycleProgressBar() {
            @Override
            public void onFinish() {
                if (countDownTimerHour != null) {
                    countDownTimerHour.onFinish();
                }
            }
        });

        mProgressMinute.setEndTime(60);
        mProgressMinute.setInitTime(minutesInitTime);
        mProgressMinute.setListener(new CircleCountDownView.OnFinishCycleProgressBar() {
            @Override
            public void onFinish() {
                if (countDownTimerMin != null) {
                    countDownTimerMin.onFinish();
                }
            }
        });

        mProgressSecond.setEndTime(60);
        mProgressSecond.setInitTime(secondsInitTime);
        mProgressSecond.setListener(new CircleCountDownView.OnFinishCycleProgressBar() {
            @Override
            public void onFinish() {
                if (countDownTimerSec != null) {
                    countDownTimerSec.onFinish();
                }
            }
        });

        startCountDownTimerHour();
        startCountDownTimerMin();
        startCountDownTimerSecond();

        // hide softkeyboard
        View currentFocus = getActivity().getCurrentFocus();
        if (currentFocus != null) {
            InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(currentFocus.getWindowToken(), 0);
        }
    }

    private void startCountDown() {
        String hours = editHours.getText().toString();
        String minutes = editMinutes.getText().toString();
        String seconds = editSeconds.getText().toString();

        if (TextUtils.isEmpty(seconds)) {
            Toast.makeText(getActivity(), "Please enter the values", Toast.LENGTH_SHORT).show();

        } else {
            showProgressBars();

            long hoursInitTime = Long.valueOf(hours);
            long minutesInitTime = Long.valueOf(minutes);
            long secondsInitTime = Long.valueOf(seconds);

            mProgressHour.setEndTime(24);
            mProgressHour.setInitTime(hoursInitTime);
            mProgressHour.setListener(new CircleCountDownView.OnFinishCycleProgressBar() {
                @Override
                public void onFinish() {
                    if (countDownTimerHour != null) {
                        countDownTimerHour.onFinish();
                    }
                }
            });

            mProgressMinute.setEndTime(60);
            mProgressMinute.setInitTime(minutesInitTime);
            mProgressMinute.setListener(new CircleCountDownView.OnFinishCycleProgressBar() {
                @Override
                public void onFinish() {
                    if (countDownTimerMin != null) {
                        countDownTimerMin.onFinish();
                    }
                }
            });

            mProgressSecond.setEndTime(secondsInitTime);
            mProgressSecond.setInitTime(secondsInitTime);
            mProgressSecond.setListener(new CircleCountDownView.OnFinishCycleProgressBar() {
                @Override
                public void onFinish() {
                    if (countDownTimerSec != null) {
                        countDownTimerSec.onFinish();
                    }
                }
            });

            startCountDownTimerHour();
            startCountDownTimerMin();
            startCountDownTimerSecond();

            // hide softkeyboard
            View currentFocus = getActivity().getCurrentFocus();
            if (currentFocus != null) {
                InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(currentFocus.getWindowToken(), 0);
            }
        }
    }

    public void showProgressBars() {
        //only for fade in
        AnimationUtil.with(mProgressSecond).duration(300).animation(AnimationUtil.FADE_IN).ready();
        AnimationUtil.with(mProgressMinute).duration(300).animation(AnimationUtil.FADE_IN).ready();
        AnimationUtil.with(mProgressHour).duration(300).animation(AnimationUtil.FADE_IN).ready();
    }

    public void startCountDownTimerSecond() {
        //Why the final time is to long?
        //In Upcoming when a countdown depends on another countdown(the countdown minute needs to wait for the second countdown to finish to be able to count)
        // it is better to work with listener. So the final time is long only so that onFinish()
        // is called only on the listener's return, not when it actually arrives at the end of the final time

        countDownTimerSec = new CountDownTimer(mProgressSecond.getEndTime() * formDays /*final time**/, 1000 /*interval**/) {
            @Override
            public void onTick(long millisUntilFinished) {
                mProgressSecond.onTick(mProgressSecond);
            }

            @Override
            public void onFinish() {
                if (countDownTimerMin != null) {
                    countDownTimerMin.cancel();
                }
                startCountDownTimerMin();
            }
        };
        countDownTimerSec.start();
    }


    public void startCountDownTimerMin() {
        countDownTimerMin = new CountDownTimer(mProgressMinute.getEndTime() * formDays /*final time**/, formDays /*interval**/) {
            @Override
            public void onTick(long millisUntilFinished) {
                mProgressMinute.onTick(mProgressMinute);
            }

            @Override
            public void onFinish() {
                if (countDownTimerHour != null) {
                    countDownTimerHour.cancel();
                }
                startCountDownTimerHour();
            }
        };
        countDownTimerMin.start();
    }


    public void startCountDownTimerHour() {
        countDownTimerHour = new CountDownTimer(mProgressHour.getEndTime() * formDays /*final time**/, formDays /*interval**/) {
            @Override
            public void onTick(long millisUntilFinished) {
                mProgressHour.onTick(mProgressHour);
            }

            @Override
            public void onFinish() {
                //this.start();
                alarmSound();
            }
        };
        countDownTimerHour.start();
    }

    public void stopCountDown() {
        cancelCounter(countDownTimerSec);
        cancelCounter(countDownTimerMin);
        cancelCounter(countDownTimerHour);

        mProgressHour.clear();
        mProgressHour.clearAnimation();
        mProgressHour.setFirstTime(true);

        mProgressMinute.clear();
        mProgressMinute.clearAnimation();
        mProgressMinute.setFirstTime(true);

        mProgressSecond.clear();
        mProgressSecond.clearAnimation();
        mProgressSecond.setFirstTime(true);
    }

    public void cancelCounter(CountDownTimer countdownTimer) {
        if (countdownTimer != null) countdownTimer.cancel();
    }

    private void alarmSound() {
        Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        Ringtone ringtone = RingtoneManager.getRingtone(getActivity().getApplicationContext(), uri);
        ringtone.play();
    }
}
