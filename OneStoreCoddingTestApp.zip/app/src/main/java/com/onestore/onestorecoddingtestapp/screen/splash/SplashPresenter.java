package com.onestore.onestorecoddingtestapp.screen.splash;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;

import com.onestore.onestorecoddingtestapp.data.AppInfo;
import com.onestore.onestorecoddingtestapp.util.DBHelperUtils;
import com.onestore.onestorecoddingtestapp.util.Utils;

import java.io.File;
import java.util.List;

public class SplashPresenter implements SplashContract.Presenter {

    private SplashContract.View view;
    private Context context;

    private DBHelperUtils dbHelperUtils;
    private Utils utils;

    public SplashPresenter(SplashContract.View view, Context context) {
        this.view = view;
        this.context = context;

        this.view.setPresenter(this);
    }

    @Override
    public void start() {
        dbHelperUtils = new DBHelperUtils(context);
        utils = new Utils(context);
    }

    @Override
    public void getAppInfoList() {
        List<PackageInfo> packageInfoList = context.getPackageManager().getInstalledPackages(PackageManager.PERMISSION_GRANTED);

        dbHelperUtils.deleteAll();
        for (PackageInfo packageInfo : packageInfoList) {
            AppInfo appInfo = new AppInfo();
            appInfo.setPkgName(packageInfo.packageName);
            appInfo.setMarket(getInstalledMarket(packageInfo.packageName));
            appInfo.setVerisonCode(String.valueOf(packageInfo.versionCode));
            appInfo.setVerisonName(packageInfo.versionName);
            appInfo.setUpdateTime(utils.dateFormat(packageInfo.lastUpdateTime));
            appInfo.setInstallTime(utils.dateFormat(packageInfo.firstInstallTime));
            appInfo.setApkPath(packageInfo.applicationInfo.sourceDir);
            appInfo.setApkSize(utils.getFileSize(new File(packageInfo.applicationInfo.sourceDir).length()));

            dbHelperUtils.add(appInfo);
        }
    }

    private String getInstalledMarket(String pkgName) {
        String maket = "";
        if ("com.android.vending".equals(context.getPackageManager().getInstallerPackageName(pkgName))) {
            maket = "PalyStore";
        } else if ("com.skt.skaf.A000Z00040".equals(context.getPackageManager().getInstallerPackageName(pkgName))) {
            maket = "OneStore";
        } else if ("com.sec.android.app.samsungapps".equals(context.getPackageManager().getInstallerPackageName(pkgName))) {
            maket = "GalaxyApps";
        } else {
            maket = "null";
        }

        return maket;
    }
}
