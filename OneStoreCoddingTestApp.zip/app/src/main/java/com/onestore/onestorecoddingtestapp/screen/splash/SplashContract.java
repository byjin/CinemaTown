package com.onestore.onestorecoddingtestapp.screen.splash;

import com.onestore.onestorecoddingtestapp.screen.BasePresenter;
import com.onestore.onestorecoddingtestapp.screen.BaseView;

public interface SplashContract {

    interface View extends BaseView<Presenter> {

        void screenUseAsyncTask();
    }

    interface Presenter extends BasePresenter {

        void getAppInfoList();
    }
}
