package com.onestore.onestorecoddingtestapp.util;

import android.content.Context;
import android.support.annotation.StringRes;
import android.support.v4.app.Fragment;
import android.widget.Toast;

public class ToastMessageUtils {
    private final Context context;

    public ToastMessageUtils(Context context) {
        this.context = context;
    }

    public ToastMessageUtils(Fragment fragment) {
        this.context = fragment.getContext();
    }

    public void shortMessage(@StringRes int stringId, Object... arguments) {
        display(context.getString(stringId, arguments), Toast.LENGTH_SHORT);
    }

    public void shortMessage(String string, Object... arguments) {
        display(String.format(string, arguments), Toast.LENGTH_SHORT);
    }

    public void longMessage(@StringRes int stringId, Object... arguments) {
        display(context.getString(stringId, arguments), Toast.LENGTH_LONG);
    }

    public void longMessage(String string, Object... arguments) {
        display(String.format(string, arguments), Toast.LENGTH_LONG);
    }

    public Toast toast(String text, int type) {
        return Toast.makeText(context, text, type);
    }

    public Toast toast(@StringRes int stringId, int type) {
        return Toast.makeText(context, stringId, type);
    }

    private void display(String string, int type) {
        toast(string, type).show();
    }
}
