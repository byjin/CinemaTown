package com.onestore.onestorecoddingtestapp.util;

import android.content.Context;
import android.support.annotation.StringRes;
import android.support.v4.app.Fragment;
import android.widget.Toast;

import java.io.File;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Utils {
    private final Context context;

    public Utils(Context context) {
        this.context = context;
    }

    public static String dateFormat(long date) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("[yyyy/MM/dd - HH:mm:ss]");
        return simpleDateFormat.format(new Date(date));
    }

    public static String getFileSize(long size) {
        if (size <= 0)
            return "0";

        final String[] units = new String[] { "B", "KB", "MB", "GB", "TB" };
        int digitGroups = (int) (Math.log10(size) / Math.log10(1024));

        return new DecimalFormat("#,##0.#").format(size / Math.pow(1024, digitGroups)) + " " + units[digitGroups];
    }
}
