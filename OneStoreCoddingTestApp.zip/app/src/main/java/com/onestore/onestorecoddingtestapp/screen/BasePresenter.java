package com.onestore.onestorecoddingtestapp.screen;

public interface BasePresenter {

    void start();
}
