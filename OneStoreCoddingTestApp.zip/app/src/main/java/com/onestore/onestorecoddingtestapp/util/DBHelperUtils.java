package com.onestore.onestorecoddingtestapp.util;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;

import com.onestore.onestorecoddingtestapp.data.AppInfo;

import java.util.ArrayList;
import java.util.List;

public class DBHelperUtils extends SQLiteOpenHelper {

    // Database Version
    private static final int DATABASE_VERSION = 1;

    // Database Name
    private static final String DATABASE_NAME = "onestoreDatabase";

    // Contacts table name
    private static final String TABLE_NAME = "app_info";

    // Contacts Table Columns names
    private static final String KEY_NO = "no";
    private static final String KEY_PKG_NAME = "pkg_name";
    private static final String KEY_MARKET = "market";
    private static final String KEY_VERSION_CODE = "verison_code";
    private static final String KEY_VERSION_NAME = "verison_name";
    private static final String KEY_UPDATE_TIME = "update_time";
    private static final String KEY_INSTALL_TIME = "install_time";
    private static final String KEY_APK_PATH = "apk_path";
    private static final String KEY_APK_SIZE = "apk_size";

    public DBHelperUtils(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_NAME + "("
                + KEY_NO + " INTEGER PRIMARY KEY,"
                + KEY_PKG_NAME + " TEXT,"
                + KEY_MARKET + " TEXT,"
                + KEY_VERSION_CODE + " TEXT,"
                + KEY_VERSION_NAME + " TEXT,"
                + KEY_UPDATE_TIME + " TEXT,"
                + KEY_INSTALL_TIME + " TEXT,"
                + KEY_APK_PATH + " TEXT,"
                + KEY_APK_SIZE + " TEXT" + ")";
        db.execSQL(createTable);
    }

    // Upgrading database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // 새로운 항목 추가
    public void add(AppInfo appInfo) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_PKG_NAME, appInfo.getPkgName());
        values.put(KEY_MARKET, appInfo.getMarket());
        values.put(KEY_VERSION_CODE, appInfo.getVerisonCode());
        values.put(KEY_VERSION_NAME, appInfo.getVerisonName());
        values.put(KEY_UPDATE_TIME, appInfo.getUpdateTime());
        values.put(KEY_INSTALL_TIME, appInfo.getInstallTime());
        values.put(KEY_APK_PATH, appInfo.getApkPath());
        values.put(KEY_APK_SIZE, appInfo.getApkSize());

        db.insert(TABLE_NAME, null, values);
        db.close();
    }

    // id 에 해당하는 row 값 가져오기
    public AppInfo get(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_NAME, new String[]{KEY_NO,
                KEY_PKG_NAME,
                KEY_MARKET,
                KEY_VERSION_CODE,
                KEY_VERSION_NAME,
                KEY_UPDATE_TIME,
                KEY_INSTALL_TIME,
                KEY_APK_PATH,
                KEY_APK_SIZE}, KEY_NO + "=?", new String[]{String.valueOf(id)}, null, null, null, null);

        if (cursor != null)
            cursor.moveToFirst();

        AppInfo appInfo = new AppInfo();
        appInfo.setNo(Integer.parseInt(cursor.getString(0)));
        appInfo.setPkgName(cursor.getString(1));
        appInfo.setMarket(cursor.getString(2));
        appInfo.setVerisonCode(cursor.getString(3));
        appInfo.setVerisonName(cursor.getString(4));
        appInfo.setUpdateTime(cursor.getString(5));
        appInfo.setInstallTime(cursor.getString(6));
        appInfo.setApkPath(cursor.getString(7));
        appInfo.setApkSize(cursor.getString(8));
        cursor.close();

        return appInfo;
    }

    // 모든 table 정보 가져오기
    public List<AppInfo> getAlls() {
        List<AppInfo> appInfoList = new ArrayList<AppInfo>();

        String query = "SELECT  * FROM " + TABLE_NAME;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            do {
                AppInfo appInfo = new AppInfo();
                appInfo.setNo(Integer.parseInt(cursor.getString(0)));
                appInfo.setPkgName(cursor.getString(1));
                appInfo.setMarket(cursor.getString(2));
                appInfo.setVerisonCode(cursor.getString(3));
                appInfo.setVerisonName(cursor.getString(4));
                appInfo.setUpdateTime(cursor.getString(5));
                appInfo.setInstallTime(cursor.getString(6));
                appInfo.setApkPath(cursor.getString(7));
                appInfo.setApkSize(cursor.getString(8));
                appInfoList.add(appInfo);

            } while (cursor.moveToNext());
        }
        cursor.close();

        return appInfoList;
    }

    // table 정보 업데이트
    public int update(AppInfo appInfo) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_PKG_NAME, appInfo.getPkgName());
        values.put(KEY_MARKET, appInfo.getMarket());
        values.put(KEY_VERSION_CODE, appInfo.getVerisonCode());
        values.put(KEY_VERSION_NAME, appInfo.getVerisonName());
        values.put(KEY_UPDATE_TIME, appInfo.getUpdateTime());
        values.put(KEY_INSTALL_TIME, appInfo.getInstallTime());
        values.put(KEY_APK_PATH, appInfo.getApkPath());
        values.put(KEY_APK_SIZE, appInfo.getApkSize());

        return db.update(TABLE_NAME, values, KEY_NO + " = ?",
                new String[]{String.valueOf(appInfo.getNo())});
    }

    // table 정보 삭제하기
    public void delete(AppInfo appInfo) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME, KEY_NO + " = ?",
                new String[]{String.valueOf(appInfo.getNo())});
        db.close();
    }

    // table 전체 정보 삭제하기
    public void deleteAll() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME, null, null);
        db.close();
    }
}
