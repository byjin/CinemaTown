package com.onestore.onestorecoddingtestapp.screen.main;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import com.onestore.onestorecoddingtestapp.R;
import com.onestore.onestorecoddingtestapp.data.AppInfo;
import com.onestore.onestorecoddingtestapp.util.DBHelperUtils;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private DBHelperUtils dbHelperUtils;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        dbHelperUtils = new DBHelperUtils(this);
        List<AppInfo> appInfoList = dbHelperUtils.getAlls();
        for (int i = 0; i < appInfoList.size(); i++) {
            /*Log.d("MAIN", "\nno :: " + appInfoList.get(i).getNo() +
                    "\npkgName :: " + appInfoList.get(i).getPkgName() +
                    "\nMarket :: " + appInfoList.get(i).getMarket() +
                    "\nVerisonCode :: " + appInfoList.get(i).getVerisonCode() +
                    "\nVerisonName :: " + appInfoList.get(i).getVerisonName() +
                    "\nUpdateTime :: " + appInfoList.get(i).getUpdateTime() +
                    "\nInstallTime :: " + appInfoList.get(i).getInstallTime() +
                    "\nApkPath :: " + appInfoList.get(i).getApkPath() +
                    "\nApkSize :: " + appInfoList.get(i).getApkSize());*/
            Log.d("MAIN", "no :: " + appInfoList.get(i).getNo() + " ||| getPkgName :: " + appInfoList.get(i).getPkgName() +
                    "\n||| getMarket :: " + appInfoList.get(i).getMarket());
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_splash, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
