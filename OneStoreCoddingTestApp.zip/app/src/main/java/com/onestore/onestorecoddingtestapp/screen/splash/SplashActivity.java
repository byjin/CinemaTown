package com.onestore.onestorecoddingtestapp.screen.splash;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;

import com.onestore.onestorecoddingtestapp.R;
import com.onestore.onestorecoddingtestapp.screen.main.MainActivity;

public class SplashActivity extends AppCompatActivity implements SplashContract.View {

    private float imageAplha = 1f;

    private SplashContract.Presenter presenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        new SplashPresenter(this, this);
        presenter.start();

        screenUseAsyncTask();
    }

    @Override
    public void setPresenter(SplashContract.Presenter presenter) {
        this.presenter = presenter;
    }

    @Override
    public void screenUseAsyncTask() {
        final AppInfoDateTask appInfoDateTask = new AppInfoDateTask();
        appInfoDateTask.execute("", "", "");

        final ImageView splashImageView = (ImageView) findViewById(R.id.splash_imageview);

        CountDownTimer countDownTimer = new CountDownTimer(1000, 100) {
            @Override
            public void onTick(long l) {
                splashImageView.setAlpha(imageAplha);
                imageAplha -= 0.1;

                if (imageAplha <= 0) {
                    imageAplha = 1;
                }
            }

            @Override
            public void onFinish() {
                imageAplha = 0;
                splashImageView.setAlpha(imageAplha);

                if (appInfoDateTask.isAsyncTaskComplete() == false) {
                    this.start();
                }
            }
        };

        countDownTimer.start();
    }

    private class AppInfoDateTask extends AsyncTask<String, String, String> {

        private boolean asyncTaskComplete = false;

        public boolean isAsyncTaskComplete() {
            return asyncTaskComplete;
        }

        public void setAsyncTaskComplete(boolean asyncTaskComplete) {
            this.asyncTaskComplete = asyncTaskComplete;
        }

        @Override
        protected void onPreExecute() {
            this.asyncTaskComplete = false;
        }

        @Override
        protected String doInBackground(String... strings) {
            presenter.getAppInfoList();
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            startActivity(new Intent(getApplicationContext(), MainActivity.class));
            finish();
            this.asyncTaskComplete = true;
        }
    }
}
