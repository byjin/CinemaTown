package com.onestore.onestorecoddingtestapp.data;

public class AppInfo {

    private int no;
    private String pkgName;
    private String market;
    private String verisonCode;
    private String verisonName;
    private String updateTime;
    private String installTime;
    private String apkPath;
    private String apkSize;

    public int getNo() {
        return no;
    }

    public void setNo(int no) {
        this.no = no;
    }

    public String getPkgName() {
        return pkgName;
    }

    public void setPkgName(String pkgName) {
        this.pkgName = pkgName;
    }

    public String getMarket() {
        return market;
    }

    public void setMarket(String market) {
        this.market = market;
    }

    public String getVerisonCode() {
        return verisonCode;
    }

    public void setVerisonCode(String verisonCode) {
        this.verisonCode = verisonCode;
    }

    public String getVerisonName() {
        return verisonName;
    }

    public void setVerisonName(String verisonName) {
        this.verisonName = verisonName;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    public String getInstallTime() {
        return installTime;
    }

    public void setInstallTime(String installTime) {
        this.installTime = installTime;
    }

    public String getApkPath() {
        return apkPath;
    }

    public void setApkPath(String apkPath) {
        this.apkPath = apkPath;
    }

    public String getApkSize() {
        return apkSize;
    }

    public void setApkSize(String apkSize) {
        this.apkSize = apkSize;
    }
}
