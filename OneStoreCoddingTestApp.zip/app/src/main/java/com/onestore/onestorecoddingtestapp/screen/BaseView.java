package com.onestore.onestorecoddingtestapp.screen;

public interface BaseView<T extends BasePresenter> {

    void setPresenter(T presenter);
}
